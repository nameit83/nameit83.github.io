All of the code is contained in the HTML file. The data for the table is taken from https://www.worldometers.info/coronavirus/ 
and the database is updated hourly. The data for the map is taken from an ESRI based serive which also updates its database hourly.

The API for the Map is having problems on Firefox based browsers so it is recommended to use a chromium or chrome based browser for
best results.

You can also access the website through https://nameit83.github.io


Data Sources:
https://corona.lmao.ninja/v2/countries
https://opendata.arcgis.com/datasets/bbb2e4f589ba40d692fab712ae37b9ac_2.geojson 

